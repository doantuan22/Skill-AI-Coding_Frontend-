"""Metadata definitions for Framework Packs, Styling Packs, and Knowledge Routing.

Machine-readable registry containing pack identities, compatible framework versions,
task affinities, priority tiers, and package-relative source paths.
"""
from __future__ import annotations

import re
from typing import Any

from uiux.engine.knowledge_router.domain_registry import DOMAIN_PACKS

# Context weight points: small=1, medium=2, large=4
WEIGHT_POINTS = {
    "small": 1,
    "medium": 2,
    "large": 4,
}


def check_version_compatibility(
    detected_version: str | None,
    version_features: dict[str, dict[str, str]] | None,
) -> dict[str, Any]:
    """Determine compatible framework features based on detected version.
    
    Hardening:
    - version known + compatible -> allows version-specific features.
    - version unknown -> generic safe tier, version-specific features suppressed.
    - version incompatible -> version-specific features suppressed.
    """
    if not version_features:
        return {
            "active_guidance_tier": "standard",
            "compatible_features": [],
            "suppressed_features": [],
        }

    if not detected_version or not detected_version.strip():
        return {
            "active_guidance_tier": "generic_safe",
            "compatible_features": [],
            "suppressed_features": [
                {"feature": f_name, "reason": "version_unknown_generic_safe"}
                for f_name in version_features
            ],
        }

    raw_nums = re.findall(r"\d+", detected_version)
    if not raw_nums:
        return {
            "active_guidance_tier": "generic_safe",
            "compatible_features": [],
            "suppressed_features": [
                {"feature": f_name, "reason": "version_unparseable_generic_safe"}
                for f_name in version_features
            ],
        }

    det_tuple = tuple(int(n) for n in raw_nums[:3])
    compatible: list[str] = []
    suppressed: list[dict[str, str]] = []

    for f_name, f_info in version_features.items():
        min_v = f_info.get("min_version", "0.0.0")
        min_nums = tuple(int(n) for n in re.findall(r"\d+", min_v)[:3])
        if det_tuple >= min_nums:
            compatible.append(f_name)
        else:
            suppressed.append({
                "feature": f_name,
                "reason": f"incompatible_version (requires >={min_v}, detected {detected_version})",
            })

    return {
        "active_guidance_tier": "compatible" if compatible else "generic_safe",
        "compatible_features": compatible,
        "suppressed_features": suppressed,
    }


FRAMEWORK_PACKS: dict[str, dict[str, Any]] = {
    "framework.react": {
        "id": "framework.react",
        "category": "framework",
        "name": "React UI Engineering Pack",
        "framework": "react",
        "version": "1.0.0",
        "version_range": ">=16.8.0",
        "version_features": {
            "hooks": {"min_version": "16.8.0", "description": "React Hooks"},
        },
        "tasks": ["create_ui", "improve_ui", "responsive_fix", "component_refactor", "page_redesign", "full_redesign", "accessibility_fix", "form_ux", "navigation_ux", "visual_polish"],
        "priority": "high",
        "source": "knowledge/frameworks/react.md",
        "required": True,
        "weight": "medium",
        "dependencies": ["framework.fallback"],
        "conflicts": ["framework.vue", "framework.svelte", "framework.angular", "framework.spring_thymeleaf"],
        "summary": "React component composition, state localization, accessible form patterns, and component preservation.",
    },
    "framework.nextjs": {
        "id": "framework.nextjs",
        "category": "framework",
        "name": "Next.js UI Engineering Pack",
        "framework": "nextjs",
        "version": "1.0.0",
        "version_range": ">=12.0.0",
        "version_features": {
            "app_router": {"min_version": "13.0.0", "description": "Next.js App Router conventions"},
        },
        "tasks": ["create_ui", "improve_ui", "responsive_fix", "component_refactor", "page_redesign", "full_redesign", "navigation_ux", "accessibility_fix", "visual_polish"],
        "priority": "high",
        "source": "knowledge/frameworks/nextjs.md",
        "required": True,
        "weight": "medium",
        "dependencies": ["framework.react"],
        "conflicts": ["framework.nuxt", "framework.sveltekit", "framework.angular"],
        "summary": "Next.js App Router and Pages Router conventions, Server/Client component boundaries, and route preservation.",
    },
    "framework.vue": {
        "id": "framework.vue",
        "category": "framework",
        "name": "Vue UI Engineering Pack",
        "framework": "vue",
        "version": "1.0.0",
        "version_range": ">=3.0.0",
        "version_features": {
            "composition_api_setup": {"min_version": "3.0.0", "description": "Vue 3 <script setup> Composition API"},
        },
        "tasks": ["create_ui", "improve_ui", "responsive_fix", "component_refactor", "page_redesign", "full_redesign", "accessibility_fix", "form_ux", "visual_polish"],
        "priority": "high",
        "source": "knowledge/frameworks/vue.md",
        "required": True,
        "weight": "medium",
        "dependencies": ["framework.fallback"],
        "conflicts": ["framework.react", "framework.svelte", "framework.angular"],
        "summary": "Vue 3 SFC conventions, Composition API script setup, scoped styling, and component preservation.",
    },
    "framework.nuxt": {
        "id": "framework.nuxt",
        "category": "framework",
        "name": "Nuxt UI Engineering Pack",
        "framework": "nuxt",
        "version": "1.0.0",
        "version_range": ">=3.0.0",
        "tasks": ["create_ui", "improve_ui", "responsive_fix", "component_refactor", "page_redesign", "full_redesign", "navigation_ux", "visual_polish"],
        "priority": "high",
        "source": "knowledge/frameworks/nuxt.md",
        "required": True,
        "weight": "medium",
        "dependencies": ["framework.vue"],
        "conflicts": ["framework.nextjs", "framework.sveltekit"],
        "summary": "Nuxt layouts, auto-imports, file-system routing in pages/, and route architecture preservation.",
    },
    "framework.svelte": {
        "id": "framework.svelte",
        "category": "framework",
        "name": "Svelte UI Engineering Pack",
        "framework": "svelte",
        "version": "1.0.0",
        "version_range": ">=4.0.0",
        "version_features": {
            "runes_reactivity": {"min_version": "5.0.0", "description": "Svelte 5 runes ($state, $derived, $props)"},
        },
        "tasks": ["create_ui", "improve_ui", "responsive_fix", "component_refactor", "page_redesign", "full_redesign", "accessibility_fix", "visual_polish"],
        "priority": "high",
        "source": "knowledge/frameworks/svelte.md",
        "required": True,
        "weight": "medium",
        "dependencies": ["framework.fallback"],
        "conflicts": ["framework.react", "framework.vue", "framework.angular"],
        "summary": "Svelte component reactivity, runes/declarations, compiler a11y adherence, and scoped CSS.",
    },
    "framework.sveltekit": {
        "id": "framework.sveltekit",
        "category": "framework",
        "name": "SvelteKit UI Engineering Pack",
        "framework": "sveltekit",
        "version": "1.0.0",
        "version_range": ">=1.0.0",
        "tasks": ["create_ui", "improve_ui", "responsive_fix", "component_refactor", "page_redesign", "full_redesign", "navigation_ux", "visual_polish"],
        "priority": "high",
        "source": "knowledge/frameworks/sveltekit.md",
        "required": True,
        "weight": "medium",
        "dependencies": ["framework.svelte"],
        "conflicts": ["framework.nextjs", "framework.nuxt"],
        "summary": "SvelteKit +layout/+page routing conventions, navigation, and nested layout preservation.",
    },
    "framework.static_html": {
        "id": "framework.static_html",
        "category": "framework",
        "name": "HTML/CSS/JS UI Engineering Pack",
        "framework": "static_html",
        "version": "1.0.0",
        "version_range": None,
        "tasks": ["create_ui", "improve_ui", "responsive_fix", "accessibility_fix", "page_redesign", "full_redesign", "visual_polish"],
        "priority": "high",
        "source": "knowledge/frameworks/static_html.md",
        "required": True,
        "weight": "medium",
        "dependencies": ["framework.fallback"],
        "conflicts": [],
        "summary": "Semantic HTML5 structure, progressive enhancement, vanilla DOM patterns, and no unsolicited framework bloat.",
    },
    "framework.spring_thymeleaf": {
        "id": "framework.spring_thymeleaf",
        "category": "framework",
        "name": "Spring Boot + Thymeleaf UI Engineering Pack",
        "framework": "spring_thymeleaf",
        "version": "1.0.0",
        "version_range": None,
        "tasks": ["create_ui", "improve_ui", "responsive_fix", "component_refactor", "accessibility_fix", "form_ux", "visual_polish"],
        "priority": "high",
        "source": "knowledge/frameworks/spring_thymeleaf.md",
        "required": True,
        "weight": "medium",
        "dependencies": ["framework.fallback"],
        "conflicts": ["framework.react", "framework.vue", "framework.nextjs"],
        "summary": "Thymeleaf template fragments, form error rendering, Bootstrap/CSS integration, and controller contract preservation.",
    },
    "framework.angular": {
        "id": "framework.angular",
        "category": "framework",
        "name": "Angular UI Engineering Pack",
        "framework": "angular",
        "version": "1.0.0",
        "version_range": ">=14.0.0",
        "version_features": {
            "modern_control_flow": {"min_version": "17.0.0", "description": "Angular @if/@for syntax"},
            "standalone_components": {"min_version": "14.0.0", "description": "Angular standalone component architecture"},
        },
        "tasks": ["create_ui", "improve_ui", "responsive_fix", "component_refactor", "page_redesign", "full_redesign", "accessibility_fix", "form_ux", "visual_polish"],
        "priority": "high",
        "source": "knowledge/frameworks/angular.md",
        "required": True,
        "weight": "medium",
        "dependencies": ["framework.fallback"],
        "conflicts": ["framework.react", "framework.vue", "framework.svelte"],
        "summary": "Angular standalone component architecture, reactive forms UI, and existing module structure preservation.",
    },
    "framework.fallback": {
        "id": "framework.fallback",
        "category": "framework",
        "name": "Generic Frontend Fallback Pack",
        "framework": "unknown",
        "version": "1.0.0",
        "version_range": None,
        "tasks": ["create_ui", "improve_ui", "responsive_fix", "accessibility_fix", "visual_polish", "general_ui"],
        "priority": "high",
        "source": "knowledge/frameworks/generic_frontend.md",
        "required": True,
        "weight": "small",
        "dependencies": [],
        "conflicts": [],
        "summary": "Universal frontend UI principles, responsive layouts, accessible markup, and safe fallback rules.",
    },
}

STYLING_PACKS: dict[str, dict[str, Any]] = {
    "styling.tailwindcss": {
        "id": "styling.tailwindcss",
        "category": "styling",
        "name": "Tailwind CSS Pack",
        "system": "tailwindcss",
        "priority": "high",
        "source": "knowledge/styling/tailwindcss.md",
        "required": True,
        "weight": "medium",
        "summary": "Tailwind utility composition, theme token discipline, responsive modifiers, and locked palette preservation.",
    },
    "styling.bootstrap": {
        "id": "styling.bootstrap",
        "category": "styling",
        "name": "Bootstrap Pack",
        "system": "bootstrap",
        "priority": "high",
        "source": "knowledge/styling/bootstrap.md",
        "required": True,
        "weight": "medium",
        "summary": "Bootstrap 12-column grid, responsive utilities, components, and anti-fight customization rules.",
    },
    "styling.plain_css": {
        "id": "styling.plain_css",
        "category": "styling",
        "name": "Plain CSS Pack",
        "system": "plain_css",
        "priority": "high",
        "source": "knowledge/styling/plain_css.md",
        "required": True,
        "weight": "small",
        "summary": "CSS custom properties, Flexbox/Grid layouts, and modular class organization.",
    },
    "styling.css_modules": {
        "id": "styling.css_modules",
        "category": "styling",
        "name": "CSS Modules Pack",
        "system": "css_modules",
        "priority": "high",
        "source": "knowledge/styling/css_modules.md",
        "required": True,
        "weight": "small",
        "summary": "Locally scoped CSS classes, style composition, and camelCase naming conventions.",
    },
    "styling.sass_scss": {
        "id": "styling.sass_scss",
        "category": "styling",
        "name": "Sass / SCSS Pack",
        "system": "sass_scss",
        "priority": "high",
        "source": "knowledge/styling/sass_scss.md",
        "required": True,
        "weight": "small",
        "summary": "SCSS module organization, variables/mixins structure, and nesting discipline.",
    },
    "styling.styled_components": {
        "id": "styling.styled_components",
        "category": "styling",
        "name": "Styled Components Pack",
        "system": "styled_components",
        "priority": "high",
        "source": "knowledge/styling/styled_components.md",
        "required": True,
        "weight": "medium",
        "summary": "Theme-driven styled primitives, transient props, and CSS-in-JS preservation.",
    },
    "styling.emotion": {
        "id": "styling.emotion",
        "category": "styling",
        "name": "Emotion Pack",
        "system": "emotion",
        "priority": "high",
        "source": "knowledge/styling/emotion.md",
        "required": True,
        "weight": "medium",
        "summary": "Emotion css prop, ThemeProvider tokens, and styled component conventions.",
    },
    "styling.mui": {
        "id": "styling.mui",
        "category": "styling",
        "name": "Material UI (MUI) Pack",
        "system": "mui",
        "priority": "high",
        "source": "knowledge/styling/mui.md",
        "required": True,
        "weight": "medium",
        "summary": "MUI ThemeProvider, sx prop, component overrides, and accessible widget preservation.",
    },
    "ui_library.shadcn_ui": {
        "id": "ui_library.shadcn_ui",
        "category": "ui_library",
        "name": "shadcn/ui Pack",
        "system": "shadcn_ui",
        "priority": "high",
        "source": "knowledge/styling/shadcn_ui.md",
        "required": True,
        "weight": "medium",
        "summary": "Radix primitives composition, cn() merging, custom variants reuse, and no blanket component regeneration.",
    },
}

PRESERVATION_PACKS: dict[str, dict[str, Any]] = {
    "preservation.existing_ui_invariants": {
        "id": "preservation.existing_ui_invariants",
        "category": "preservation",
        "name": "Existing UI Preservation Invariants",
        "priority": "critical",
        "source": "knowledge/preservation/existing_ui_invariants.md",
        "required": True,
        "weight": "medium",
        "summary": "Locked color palette, protected layout identity, L1/L2/L3 change budgets, and precedence rules.",
    },
}

RUNTIME_VALIDATION_PACKS: dict[str, dict[str, Any]] = {
    "runtime.responsive_viewport": {
        "id": "runtime.responsive_viewport",
        "category": "runtime",
        "name": "Responsive Viewport Validation",
        "priority": "medium",
        "source": "knowledge/runtime-validation/responsive_viewport.md",
        "required": False,
        "weight": "small",
        "summary": "Multi-breakpoint verification (375px, 768px, 1440px), no horizontal overflow, and touch target checks.",
    },
    "runtime.accessibility_audit": {
        "id": "runtime.accessibility_audit",
        "category": "runtime",
        "name": "Accessibility Audit Validation",
        "priority": "medium",
        "source": "knowledge/runtime-validation/accessibility_audit.md",
        "required": False,
        "weight": "small",
        "summary": "WCAG AA contrast verification, form label association, heading hierarchy, and keyboard focus outlines.",
    },
    "runtime.form_interaction": {
        "id": "runtime.form_interaction",
        "category": "runtime",
        "name": "Form Interaction Validation",
        "priority": "medium",
        "source": "knowledge/runtime-validation/form_interaction.md",
        "required": False,
        "weight": "small",
        "summary": "Input blur validation, inline error presentation, and submitting disabled button states.",
    },
    "runtime.smoke_test": {
        "id": "runtime.smoke_test",
        "category": "runtime",
        "name": "Smoke Test Validation",
        "priority": "medium",
        "source": "knowledge/runtime-validation/smoke_test.md",
        "required": False,
        "weight": "small",
        "summary": "Page render verification, zero console errors, and basic clickable element responsiveness.",
    },
}

DESIGN_SKILLS: dict[str, dict[str, Any]] = {
    "skill.responsive_interaction": {
        "id": "skill.responsive_interaction",
        "category": "skill",
        "name": "Responsive & Interaction Skill",
        "priority": "high",
        "source": "skills/responsive-interaction",
        "required": False,
        "weight": "medium",
        "summary": "Mobile-first responsive adaptations, touch targets, and viewport reflow.",
    },
    "skill.visual_qa": {
        "id": "skill.visual_qa",
        "category": "skill",
        "name": "Visual QA & Accessibility Skill",
        "priority": "high",
        "source": "skills/visual-qa",
        "required": False,
        "weight": "medium",
        "summary": "Visual quality assurance, contrast verification, and WCAG accessibility standards.",
    },
    "skill.ux_structure": {
        "id": "skill.ux_structure",
        "category": "skill",
        "name": "UX Structure & Information Architecture Skill",
        "priority": "high",
        "source": "skills/ux-structure",
        "required": False,
        "weight": "medium",
        "summary": "Information architecture, page shell structure, and navigational hierarchy.",
    },
    "skill.component_realization": {
        "id": "skill.component_realization",
        "category": "skill",
        "name": "Component Realization Skill",
        "priority": "high",
        "source": "skills/component-realization",
        "required": False,
        "weight": "medium",
        "summary": "UI component implementation, variants, and design token integration.",
    },
    "skill.typography": {
        "id": "skill.typography",
        "category": "skill",
        "name": "Typography Skill",
        "priority": "medium",
        "source": "skills/typography",
        "required": False,
        "weight": "small",
        "summary": "Font hierarchy, line height rhythm, and typographic scale discipline.",
    },
    "skill.design_direction": {
        "id": "skill.design_direction",
        "category": "skill",
        "name": "Design Direction Skill",
        "priority": "medium",
        "source": "skills/design-direction",
        "required": False,
        "weight": "large",
        "summary": "Holistic visual direction, moodboards, and style definition for new interfaces.",
    },
    "skill.design_inspiration": {
        "id": "skill.design_inspiration",
        "category": "skill",
        "name": "Design Inspiration Skill",
        "priority": "low",
        "source": "skills/design-inspiration",
        "required": False,
        "weight": "large",
        "summary": "Creative design inspiration, visual references, and innovative aesthetics.",
    },
    "skill.final_quality_gate": {
        "id": "skill.final_quality_gate",
        "category": "skill",
        "name": "Final Quality Gate Skill",
        "priority": "high",
        "source": "skills/final-quality-gate",
        "required": False,
        "weight": "small",
        "summary": "Strict pre-delivery audit against design specs, preservation rules, and edge cases.",
    },
}
