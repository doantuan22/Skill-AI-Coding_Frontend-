module.exports = { use: { baseURL: 'http://127.0.0.1:4173' } };
